#!/usr/bin/env python
from unicodedata import name
from setuptools import setup
if __name__ == "__main__":
    setup()